//
//  ProcessingViewController.h
//  PINRemoteImage
//
//  Created by Garrett Moon on 7/16/15.
//  Copyright (c) 2015 Garrett Moon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProcessingViewController : UIViewController

@property (nonatomic, weak) IBOutlet UIImageView *imageView;

@end
