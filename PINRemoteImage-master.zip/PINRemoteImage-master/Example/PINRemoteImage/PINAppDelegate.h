//
//  PINAppDelegate.h
//  PINRemoteImage
//
//  Created by CocoaPods on 08/11/2014.
//  Copyright (c) 2014 Garrett Moon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PINAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
